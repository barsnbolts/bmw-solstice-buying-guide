# B58, B48/B46 and N55 market evidence

Observed 2026-09-25. The JSON contains 31 unique URLs: 30 displayed USD asking prices and one sold listing retained with `price: null` because the seller wrote “PRICES VARY.” Prices are individual listing asks, not completed sale values; displayed freight is noted separately and is not added. Direct item/product pages were opened. Status refers to what the page showed on the observation date; ended listings are historical asks only.

Model lines in titles usually describe seller fitment, not the engine's source car. Engine codes and mileage are seller-stated unless an item-specific source is named. `null` means the listing did not establish that field. Do not infer B48/B46 from the 530i badge, or treat broad fitment lists as verified interchange. No currency conversion is applied to the Canadian seller's USD eBay ask.

## Engine and core listings

| Record | Evidence from opened listing | Price/status |
|---|---|---:|
| [B58B30M2, 4k mi, 540i/740i/840i/M340i RWD fitment](https://www.ebay.com/itm/117425730495) | Used Auto Parts You Need; $7,379.18, title calls it a complete assembly and names B58B30M2. Actual source VIN/year is unstated; only local pickup is shown, with no exact item location or shipping offer. Do not treat as confirmed NA-accessible. | $7,379.18 USD; current displayed ask, access unverified |
| [540 G30 AWD, “B58 GEN 2,” 31k mi](https://www.ebay.com/itm/336244167792) | torens_usa; $7,200. Generation wording and mileage are title claims; exact engine code absent. | $7,200 USD; current ask |
| [2017 540i xDrive complete engine](https://www.ebay.com/itm/157630954074) | QUALITY AUTO; $5,999 plus listed $450 freight. Seller says all parts came from a 2017 540i xDrive; code and mileage absent. | $5,999 USD; current ask |
| [2020-23 540i B58B30M1, 9,441 mi](https://www.go-parts.com/hl-product.php?make=BMW&model=540i&sku=PB-6494-0000017158-211065) | Go-Parts; $8,100. Page calls it a 335 hp B58B30M1, complete used engine, and says it is not the higher-output M40i/M340i version; notes 90-day warranty and possible oil-pan/mount transfer. | $8,100 USD; Add to Cart shown |
| [2016-19 740i RWD B58B, 57k mi](https://www.ebay.com/itm/287392362055) | CARisma M&P; $7,195.75. Seller title says 320 hp and part number 11002455303. Optional coupon was shown separately. | $7,195.75 USD; current ask |
| [2019 X3 M40i AWD B58B30A, 92k mi](https://www.ebay.com/itm/168320777916) | okautopartsms; $6,000. Listing ended July 28, 2026 because seller marked it an error; historical ask, not a sale. | $6,000 USD; ended |
| [2019-21 X5 sDrive40i B58B30C, 60k mi](https://www.ebay.com/itm/377137263707) | PartsBoxBelton; $7,994.99 plus $325 freight. Item specifics identify a 2021 donor VIN; title says RWD. | $7,994.99 USD; current ask |
| [“B58D” / B58B30B code conflict, 16 mi](https://www.ebay.com/itm/116983795346) | BMWGravedigger's German Parts; $9,549.95. Title says B58D, item specifics give part number B58B30B, and seller says the oil pan must be replaced. | $9,549.95 USD; current ask, unresolved variant |
| [2019-26 Supra B58 engine, 79,432 mi](https://www.ebay.com/itm/237014194411) | Boosted Auto Collection; $9,000. Seller says tested/operational and lists an engine assembly. “A/T” in the title is not evidence that a transmission is included. | $9,000 USD; current ask |
| [2021-24 Supra B58 core, parts needed](https://www.ebay.com/itm/236330748852) | BlackGoldAutoParts, Canadian seller; $7,745.50 USD. Seller explicitly says valve cover, oil pan and oil-pan sensor are needed. | $7,745.50 USD; current ask, incomplete |
| [2020 M340i B58 engine plus automatic transmission, 59k mi](https://www.ebay.com/itm/227481463232) | MIAMI FINE AUTO; $9,499. Seller title explicitly advertises an engine-and-automatic package. This is one package ask, not separate component values. | $9,499 USD; current ask |
| [2020 M340i B58 engine only, 64k mi](https://www.ebay.com/itm/188352631999) | Arizona Auto and Truck Parts; $9,259.95. Seller explicitly says turbo is not included; free business-address freight and six-month warranty are advertised. | $9,259.95 USD; current ask |
| [B48B20B, 2019 530i](https://www.ebay.com/itm/325448907606) | Motorteiledirekt.de; $4,079 plus $359 shipping from Hamm, Germany. Page displays US delivery; seller title is global application wording and actual donor is unstated. Raw import lead only; exclude from US/Canada seller-location statistics. | $4,079 USD; current ask, non-NA seller |
| [2017 530i AWD 2.0L engine, 54,926 mi](https://www.blueprismautomotive.com/product-page/2017-bmw-530i-2-0l-awd-engine-motor-assembly-for-sale) | Blue Prism Automotive; $6,100. Seller claims B48, complete dress, compression/leak checks and one-year warranty; page also says “Call For Availability.” | $6,100 USD; displayed ask, stock unconfirmed |
| [2017 530i 2.0L engine, 138k mi, LKQ448848052](https://www.ebay.com/itm/366381459236) | LKQ; $3,604. Listing ended June 29, 2026 because no longer available. Code is unstated, so family remains unresolved. | $3,604 USD; ended ask |
| [B46B20B, 2019-24 330i G20 RWD fitment](https://www.ebay.com/itm/336495830234) | torens_usa; $3,999. Code is in seller title; mileage/source donor not stated. | $3,999 USD; current ask |
| [B46D, 2020-21 X3 30i G01, 48,829 mi](https://www.ebay.com/itm/115819715555) | My Parts Plaza; $4,289. Title says B46D; item specifics list B46/B46D/B46B20B, so exact code stays unresolved. | $4,289 USD; current ask |
| [B46B20B, 2017-19 530i/X3/X4 AWD fitment, 70k mi](https://www.ebay.com/itm/236425639631) | Viking Used Auto Parts; $3,386.63, Oroville CA. Seller says running test was smooth and no major teardown leak found; actual donor not identified. | $3,386.63 USD; current ask |
| [B46B20B, 2019-21 330i/530i RWD long block, 80k mi](https://www.ebay.com/itm/227335996675) | Straight Six Auto Parts; $1,950 plus $295.95 freight, Oceanside CA. Seller's long-block and complete-assembly wording conflicts; contents unenumerated. | $1,950 USD; current ask |

## Transmission and package listings

| Record | Evidence from opened listing | Price/status |
|---|---|---:|
| [2019-20 X5 G05 xDrive40i automatic, 2k mi](https://www.ebay.com/itm/128046033388) | Spartan Auto; $1,260 plus $275 freight. Source tag indicates 2020, but no transmission code is given. | $1,260 USD; current ask |
| [2017-23 540 G30 RWD GA8HP50Z, 90k mi](https://www.ebay.com/itm/206272428894) | capstoneautoparts; $1,045. Seller says excellent condition; seller-stated mileage. | $1,045 USD; current ask |
| [2018-19 AWD 340i/440i/M240i 8HP50Z, 59,458 mi](https://www.ebay.com/itm/407077811876) | oeM Garage FL; $1,499.95. Title gives 8HP50Z; item specifics identify a 2019 440i xDrive donor. | $1,499.95 USD; current ask |
| [2020-22 M340i/Z4 M40i RWD automatic](https://www.ebay.com/itm/405194861185) | oeM Garage FL; $2,095.95. Seller does not state exact code and discloses a slightly bent rear connector. | $2,095.95 USD; current ask |
| [2017 F87 M2 GS7D36SG DCT, 34k mi](https://www.redlineautoparts.com/bmw/2015-2018-bmw-m2-dct-dual-clutch-automatic-transmission-gs7d36sg-b2008/) | Redline Auto Parts; $2,499.99, SKU 967580949625. Seller describes a 2017 running donor and says some hardware/shift lever must be reused. Page is live but stock quantity is not exposed. | $2,499.99 USD; stock unresolved |
| [2012-18 335i xDrive 8HP45X automatic](https://www.ebay.com/itm/357528611332) | Part-O-Mart; $899.99 plus $265 shipping. No donor mileage given. | $899.99 USD; current ask |

## N55 engine listings

| Record | Evidence from opened listing | Price/status |
|---|---|---:|
| [F30 335i N55 with turbo, 73k mi](https://www.ebay.com/itm/188641082513) | City Motors Chicago; $5,130. Seller title identifies N55 and turbo; actual source model year not stated. | $5,130 USD; current ask |
| [335i/535i N55 engine, 90k mi](https://www.ebay.com/itm/198300393255) | TheseImports; $2,999.94. Seller claims tested good/good compression. | $2,999.94 USD; current ask |
| [AWD N55 multi-application engine](https://www.ebay.com/itm/327104443762) | GERMAN AUTO RESORT; $3,248.95. Seller title lists 335i/X1/X5/X6/535i applications; mileage/source VIN absent. | $3,248.95 USD; current ask |
| [F87 M2 N55 long block, title says 47k mi](https://www.ebay.com/itm/405805573613) | oem-garage; $7,499.95. Seller discloses a small oil-pan crack and JB Weld used for a compression test. This is a long block, not a dressed assembly; the broad 2016-21 N55 title is unresolved. | $7,499.95 USD; current ask |
| [X4 M40i N55B30, 117k mi](https://www.ebay.com/itm/117255152782) | AUTOHUB SHOP; $4,137.23. Seller says it came from an X4 M40i and was compression-tested; title also mentions M2 fitment, while seller describes oil-pan changes for that possible application. | $4,137.23 USD; current ask |

## Sold listing with no usable price

[B46D, 2019-23 330i/430i/530i/X3 fitment, title says 30k mi](https://www.ebay.com/itm/327265889068) was marked SOLD. The page displayed $3,800 but the seller note says “PRICES VARY”; JSON `price` is therefore `null`, and this is not treated as either an individual ask or a confirmed transaction price.

## Gaps and caution

The evidence set has one explicit engine-plus-transmission package ask; most sources price engines and gearboxes separately. Transmission labels/codes are retained only where a listing actually states them. The separate engine/transmission asks should not be added to imply a package price. Long blocks, complete assemblies, damaged cores and seller-stated tested engines remain separate categories.

Kijiji search returned Ontario whole-vehicle N55 donor leads, including a 2011 535GT xDrive listing at $6,500 with 186,000 km and a 2018 M2 listing at $49,995, 40,000 km. Direct Kijiji opens returned HTTP 429. These were not engine or transmission part-outs and their snippet prices are not included as drivetrain asks. No seller was contacted. Broader Kijiji part-out coverage remains an access gap.

This file supplies listing evidence only. It does not establish physical compatibility, a generation map, swap fit, seller claim truth, final statistical groups or a recommended drivetrain; mainline owns those conclusions.

# B46/B48 engine specification comparison

Eight exact model-year application rows document a 2.0-litre four-cylinder progression from North-American B46 donors to B48 O1/O2, Toyota's code-undisclosed Supra 2.0, a PHEV engine, and a transverse high-output M235. Numerical performance figures are U.S.-market published SAE hp and lb-ft where BMW/Toyota supplied them. See [specs-b48.json](specs-b48.json) for row data and source URLs.

The comparison rejects a blanket “B46 equals B48, tune-only” conclusion. The 2019 B46's change from the 2017 248 hp/258 lb-ft baseline to 255/295 coincides with BMW's documented 350-bar injection, lighter crankshaft, lower internal friction, heat-management work and turbo-system optimization. A later 255/295 rating can still hide distinct hardware: B48B20O1, B48B20O2 and Toyota's code-undisclosed Supra application are not documented as the same assembly.

The MY2025 M235 xDrive Gran Coupe is the clearest material high-output example. BMW reports 9.5:1 compression, a stronger crankshaft, revised main-bearing shells/covers, changed oil supply to piston-cooling channels, increased turbocharging and charge-air cooling, and 312 hp. Its transverse layout adds packaging differences from longitudinal BMW 2/3/5-Series donors. BMW's public U.S. release does not state the full M235 engine code, so it is left null.

Compression ratios show meaningful reported variation: 10.2:1 on the cited B46/O1 and 330e, 10.5:1 on the 2025 330i O2, and 9.5:1 on the M235. BMW's 2025 X3 30 release reports 11.6:1 for B48B20O2 despite the same code and output being listed at 10.5:1 for the 330i. Both values are preserved with a source-conflict caveat; public evidence reviewed does not resolve whether this reflects a document error or an application distinction.

The 330e row reports only the gasoline engine's 181 hp/258 lb-ft. Its 107-hp electric machine and 288-hp/310-lb-ft system output remain separate; the electric machine is integrated in the transmission. Toyota confirms the 2021 Supra 2.0's 255 hp/295 lb-ft, twin-scroll turbo, direct injection and variable timing on both camshafts, but does not disclose the BMW engine code, displacement in cc, compression, bore/stroke or internals in the U.S. primary sources reviewed.

No row asserts parts interchange. Confirm the donor VIN/build month, engine code, emissions label, turbo, fuel system, sump/pickup, accessory drive and hybrid completeness before treating an engine as a usable donor. BMW's technical-training reference documents additional B46TU/B48TU and high-output transverse hardware differences: [ST1910 B46TU/B48TU Engine](https://bmwtechinfo.bmwgroup.com/tech_training_manual/ST1910%20B46TU-B48TU%20Engine.pdf).

## Mainline acceptance correction

The 2025 X3 30 technical table labels 255 hp / 295 lb-ft as system ratings. Its engine-only hp, torque and associated RPM fields are therefore null in the final JSON; the published system figures remain in its caveat. Compression values are normalized to explicit `:1` strings without changing their numeric values. The 2021 330e 181 hp / 258 lb-ft engine-only figures were independently checked against both the BMW prose and technical table.

# Asking-price cohorts

Selected accessible asks, not a representative market census. All figures exclude freight, tax and fees. No measured healthy dressed 2020 M2C/55,000-km cohort.

| Cohort | n | Mean USD | Median USD | Mean CAD | Median CAD | CAD range |
|---|---:|---:|---:|---:|---:|---:|
| S55 · explicitly complete with turbos/accessories | 1 | 10,495.00 | 10,495.00 | 14,835.73 | 14,835.73 | 14,835.73–14,835.73 |
| S55 · turbo-equipped, accessories unspecified | 5 | 9,379.00 | 9,500.00 | 13,258.15 | 13,429.20 | 11,308.80–14,842.80 |
| S55 · near-mileage M2C assemblies | 2 | 12,497.50 | 12,497.50 | 17,666.47 | 17,666.47 | 17,662.93–17,670.00 |
| B58 original · turbo-equipped recycler assemblies | 4 | 5,177.50 | 5,175.00 | 7,318.92 | 7,315.38 | 6,643.92–8,000.98 |
| S58 · G8x seller-described complete/dropout | 3 | 13,337.47 | 13,500.00 | 18,853.84 | 19,083.60 | 17,843.17–19,634.76 |
| S58 · early X3 M SUV assembly | 1 | 11,000.00 | 11,000.00 | 15,549.60 | 15,549.60 | 15,549.60–15,549.60 |
| DCT · seller-advertised F8x assemblies | 2 | 1,500.00 | 1,500.00 | 2,120.40 | 2,120.40 | 1,979.04–2,261.76 |
| 8HP45 · N55 RWD assemblies | 3 | 600.72 | 643.03 | 849.18 | 908.99 | 507.68–1,130.87 |
| 8P75H · F30 330e PHEV transmissions | 2 | 1,230.00 | 1,230.00 | 1,738.72 | 1,738.72 | 1,272.24–2,205.20 |
| 8HP76 · S58 xDrive assemblies | 2 | 3,747.98 | 3,747.98 | 5,298.14 | 5,298.14 | 4,947.60–5,648.67 |
| B58 TU · M340i engine/automatic package | 1 | 9,499.00 | 9,499.00 | 13,427.79 | 13,427.79 | 13,427.79–13,427.79 |
| B58 TU medium-output · M1 seller label | 1 | 8,100.00 | 8,100.00 | 11,450.16 | 11,450.16 | 11,450.16–11,450.16 |
| B46 · G20 seller code B46B20B | 1 | 3,999.00 | 3,999.00 | 5,652.99 | 5,652.99 | 5,652.99–5,652.99 |
| B46 · G01 seller code B46D | 1 | 4,289.00 | 4,289.00 | 6,062.93 | 6,062.93 | 6,062.93–6,062.93 |
| B46 · AWD B46B20B assembly | 1 | 3,386.63 | 3,386.63 | 4,787.34 | 4,787.34 | 4,787.34–4,787.34 |
| B46 · RWD B46B20B long block | 1 | 1,950.00 | 1,950.00 | 2,756.52 | 2,756.52 | 2,756.52–2,756.52 |
| B48 · 330i/230i seller-labelled assembly | 1 | 3,500.00 | 3,500.00 | 4,947.60 | 4,947.60 | 4,947.60–4,947.60 |
| N55 ordinary · unspecified-dress assemblies | 2 | 3,124.45 | 3,124.45 | 4,416.72 | 4,416.72 | 4,240.72–4,592.72 |
| N55 X4 M40i · separate assembly | 1 | 4,137.23 | 4,137.23 | 5,848.39 | 5,848.39 | 5,848.39–5,848.39 |
| 8HP70X · BMW V8 donor, adaptation only | 1 | 1,089.89 | 1,089.89 | 1,540.67 | 1,540.67 | 1,540.67–1,540.67 |
| 8HP75 · BMW V8 donor, adaptation only | 1 | 1,250.00 | 1,250.00 | 1,767.00 | 1,767.00 | 1,767.00–1,767.00 |

## S55 · explicitly complete with turbos/accessories
One 87,498-mile M4. Seller-stated used condition; not a 55,000-km benchmark.
IDs: CP-S04

## S55 · turbo-equipped, accessories unspecified
M2/M4; 50,285–106,000 miles plus one unknown. No mileage normalization; not fully dressed parity.
IDs: CP-S03, CP-S05, CP-S06, CP-S07, CP-S08

## S55 · near-mileage M2C assemblies
2021 M2C, 29k/33k miles. Dress unspecified. Adjacent evidence only; exact 2020 dressed cohort n=0.
IDs: CP-S01, CP-S02

## B58 original · turbo-equipped recycler assemblies
740i/540i/X3 M40i; 83,546–109,228 miles. Accessories unspecified. No claim of identical engine suffix or dress.
IDs: CP-B01, CP-B02, CP-B06, CP-B08

## S58 · G8x seller-described complete/dropout
8,102 / 28,586 / unknown miles. Complete/dropout is seller language; attached hardware not enumerated. RWD/xDrive retained as a market descriptor, not interchange proof.
IDs: s58-ebay-cyber-2024-m3-8102mi, s58-ebay-waltz-rwd-28586mi, s58-ebay-pacificmotors-dropout-11005a16be3

## S58 · early X3 M SUV assembly
Single 51,000-mile listing, 2021 donor according to seller compatibility/VIN metadata. Separate from MY2022-on crankshaft revision. Exact dress unresolved.
IDs: s58-ebay-partsbox-x3mcomp-51kmi

## DCT · seller-advertised F8x assemblies
Used gearbox asks. Sellers say GS7D36SG; BMW training says BG, while F80 parts-catalog mirror also says SG. Nomenclature conflict, not proof of incompatibility. Exact donor/part/case unresolved.
IDs: dct_gs7d36sg_398157193876, dct_gs7d36sg_117202560560

## 8HP45 · N55 RWD assemblies
F10/F30 N55 RWD. Converter/ancillaries unspecified; individual tag verification still required.
IDs: hp45z_n55_f10_304774084202, hp45_n55_f30_336416648274, hp45z_n55_f30_168381177260

## 8P75H · F30 330e PHEV transmissions
Hybrid-specific, not an ordinary 8HP. Included electric/hybrid equipment unresolved.
IDs: phev_8p75hz_f30_188348537998, phev_8p75hz_f30_188046467046

## 8HP76 · S58 xDrive assemblies
One title/notes Z/X conflict; seller notes say X. Transfer case not established. Keep separate from RWD.
IDs: hp76x_s58_g80_227335650362, hp76x_s58_g80_227353377806

## B58 TU · M340i engine/automatic package
Single seller package at 59,000 miles; accessory list and exact transmission tag not enumerated. No package-market median can be inferred from one item.
IDs: b58-ebay-m340i-package-2020-59kmi

## B58 TU medium-output · M1 seller label
Single seller-described B58B30M1 complete engine, 9,441 miles. Do not pool with higher-output TU or original B58.
IDs: b58-goparts-540i-b58b30m1-9441mi

## B46 · G20 seller code B46B20B
Single engine assembly; mileage/dress unresolved. Not pooled with B46D or B48.
IDs: b46-ebay-g20-330i-b46b20b

## B46 · G01 seller code B46D
Single X3 30i complete-engine claim, 48,829 miles; exact attachments unresolved.
IDs: b46-ebay-g01-x3-30i-b46d-48829mi

## B46 · AWD B46B20B assembly
Single California seller engine at 70,000 title-stated miles. Actual donor remains unresolved; accessory inventory incomplete.
IDs: b46-ebay-530i-x3-x4-b46b20b-awd-70kmi

## B46 · RWD B46B20B long block
Single 80,000-mile seller long-block title. Listing also says complete assembly; conservative long-block classification, not dressed-engine price.
IDs: b46-ebay-g20-g30-b46b20b-rwd-longblock-80kmi

## B48 · 330i/230i seller-labelled assembly
Single 78,000-mile seller-described complete engine. Exact donor/year/emissions code unresolved; no longitudinal-gen normalization.
IDs: ebay-177691040750-b48-engine

## N55 ordinary · unspecified-dress assemblies
Two ordinary N55 advertised assemblies; fitment titles are not donor identities. 90k miles / unknown, exact version and accessories unresolved. M2 and X4 M40i excluded.
IDs: n55-ebay-335i-535i-2011-15-90kmi, n55-ebay-awd-335i-x1-x5-x6-535i-tested

## N55 X4 M40i · separate assembly
Single special-application N55 ask, 117,000 miles; accessories unspecified. Do not apply to ordinary N55 or original M2.
IDs: n55-ebay-x4m40i-117kmi

## 8HP70X · BMW V8 donor, adaptation only
Single BMW 750i transmission-only candidate. Direct-page ask differs from lower search result; no factory pairing to target engines claimed.
IDs: hp70x_n63_f01_389247636039

## 8HP75 · BMW V8 donor, adaptation only
Single 69,130-mile 750i xDrive transmission. Seller says GA8HP75Z despite AWD donor; resolve exact output/case before purchase.
IDs: hp75z_n63_g12_188386992150
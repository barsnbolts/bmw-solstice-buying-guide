# B58 engine specification comparison

Research cut: 2026-09-26. U.S. model years, manufacturer-rated SAE horsepower. Row-level machine-readable values and source links are in [`specs-b58.json`](specs-b58.json). `null` means the reviewed primary source did not establish the value. Engine type, geometry, and output are model-specific evidence; common family branding does not prove assembly or parts interchange.

## Representative applications

| Exact U.S. model year / donor | Engine identification | Compression | Engine hp / torque | Decision-useful distinction |
|---|---|---:|---:|---|
| 2016 BMW 340i F30 | B58B30M0 | 11.0:1 | 320 / 330 lb-ft | Original B58 passenger-car baseline. |
| 2017 BMW 540i G30 | B58B30M0 | 11.0:1 | 335 / 332 lb-ft | Same published type and core geometry; higher model rating. |
| 2017 BMW 740i G12 | B58B30M0 | 11.0:1 | 322 / 332 lb-ft | Same code/core specs, distinct 7 Series installation. |
| 2018 BMW X3 M40i G01 | B58B30M0 | 11.0:1 | 355 / 369 lb-ft | Higher-output SUV application with its own xDrive and cooling package. |
| 2020 BMW M340i G20 | B58TU family; exact suffix not in U.S. release | 10.2:1 | 382 / 369 lb-ft | 350-bar direct injection and turbo-integrated steel exhaust manifold. |
| 2020 Toyota GR Supra 3.0 A90 | Toyota does not publish BMW suffix | 11.0:1 | 335 / 365 lb-ft | BMW-collaboration engine; specific hardware interchange is not established. |
| 2021 Toyota GR Supra 3.0 A90 | Toyota does not publish BMW suffix | 10.2:1 | 382 / 368 lb-ft | New pistons and six-port dual-branch exhaust manifold versus MY2020. |
| 2023 BMW 740i G70 | B58TU2 designation | Not stated in cited U.S. release | 375 / 383 lb-ft | Miller cycle, dual injection, integrated exhaust-manifold head, electric VANOS, 48V assist. |
| 2021 BMW X5 xDrive45e G05 | B58B30M1 SULEV30 | 11.0:1 | 282 / 331 lb-ft | Engine-only output; 389 hp / 443 lb-ft are combined system figures. |
| 2024 BMW X5 xDrive50e G05 | Exact suffix not stated in cited U.S. release | 11.0:1 | 308 / 331 lb-ft | Engine-only output; 483 hp / 516 lb-ft are combined system figures. |

## Comparisons that affect donor selection

**Original B58 ratings are application calibrations, not a single output.** BMW's published examples run from 320 hp in the 340i to 335 hp in the 540i, 322 hp in the 740i, and 355 hp in the X3 M40i. The 340i, 540i, and 740i sources give B58B30M0, 2,998 cc, 82 x 94.6 mm, and 11:1; the X3 source confirms 355 hp / 369 lb-ft and describes its intake-manifold-integrated indirect charge-air cooler. These overlaps establish family/type and published specification—not complete assembly, turbo, sump, or accessory interchange. Sources: [BMW 2016 340i](https://www.press.bmwgroup.com/usa/article/detail/T0216443EN_US/the-new-bmw-3-series-sedan-and-sports-wagon), [BMW 2017 540i](https://www.press.bmwgroup.com/usa/article/detail/T0264802EN_US/the-all-new-2017-bmw-5-series%3A-performance-redefined), [BMW 2017 740i technical data](https://www.press.bmwgroup.com/usa/article/attachment/T0221442EN_US/387824), [BMW 2018 X3 M40i](https://www.press.bmwgroup.com/usa/article/detail/T0272041EN_US/the-all-new-2018-bmw-x3).

**B58TU differs in hardware from the original generation.** The 2020 M340i is 382 hp / 369 lb-ft at 10.2:1. BMW specifies direct injection up to 350 bar and a single twin-scroll turbo with an integrated compact steel exhaust manifold. BMW training material describes TU split-cooling and fuel/turbo changes; public U.S. M340i material does not expose the full type suffix. Sources: [BMW 2020 M340i](https://www.press.bmwgroup.com/usa/article/detail/T0286917EN_US/the-all-new-2020-bmw-m340i-and-m340i-xdrive-sedans), [BMW B58TU training manual](https://bmwtechinfo.bmwgroup.com/tech_training_manual/ST1853%20B58TU%20Engine.pdf).

**Toyota documented a substantive Supra 3.0 MY2021 engine revision.** MY2020 is 335 hp / 365 lb-ft and 11:1. For MY2021, Toyota reports new pistons lowering compression to 10.2:1 and a new six-port dual-branch exhaust manifold in place of the two-port design; output rises to 382 hp / 368 lb-ft. The result shares the B58 family relationship and nominal output with BMW's TU M340i, but Toyota describes different exhaust hardware. Neither source proves common pistons, turbochargers, long blocks, or service-part compatibility. Sources: [Toyota 2020 Supra product data](https://pressroom.toyota.com/2020-supra-product-supra/), [Toyota 2021 engine update](https://pressroom.toyota.com/2021-toyota-gr-supra-hits-the-streets-with-more-power-a91-edition-and-first-ever-four-cylinder-turbo-model/), [BMW 2020 M340i](https://www.press.bmwgroup.com/usa/article/detail/T0286917EN_US/the-all-new-2020-bmw-m340i-and-m340i-xdrive-sedans).

**B58TU2 has a clearly published mechanical revision.** BMW calls the 2023 740i engine B58TU2 and specifies Miller-cycle operation, revised intake ports/chambers, electrically controlled VANOS, dual direct/port injection, an integrated exhaust-manifold head, and switchable exhaust-side rocker arms. Rated engine output is 375 hp / 383 lb-ft; the 48V motor can briefly add torque, so the higher assisted value is not engine-only torque. Source: [BMW 2023 7 Series](https://www.press.bmwgroup.com/usa/article/detail/T0382613EN_US/the-new-bmw-7-series).

**PHEV system ratings must stay separate from engine output.** The 2021 X5 xDrive45e's B58B30M1 SULEV30 is 282 hp / 331 lb-ft; 389 hp / 443 lb-ft is combined engine-and-motor output. The 2024 X5 xDrive50e's revised B58-family engine is 308 hp / 331 lb-ft; 483 hp / 516 lb-ft is combined output. BMW explicitly identifies dual injection and the integrated exhaust-manifold head on the 50e. Its exact suffix is not stated in the reviewed U.S. release. Sources: [BMW 2021 X5 xDrive45e](https://www.press.bmwgroup.com/usa/article/detail/T0309345EN_US/the-2021-bmw-x5-xdrive45e-phev-sports-activity-vehicle), [BMW 2024 X5 xDrive50e](https://www.press.bmwgroup.com/usa/article/detail/T0408460EN_US/the-2024-bmw-x5-and-x6).

## Limits

- BMW/Toyota sources do not establish cross-model or BMW-to-Toyota part-number interchange. Confirm VIN, production date, emissions specification, and the actual assembly contents before buying.
- BMW U.S. model releases omit full engine suffixes for some M340i, Supra-related, TU2, and PHEV applications. Those JSON codes remain `null` where the reviewed primary source does not close the identification.
- No boost-pressure figures or exact turbo part numbers were inferred from output. A shared B58 family name, compression ratio, or horsepower rating is not parts-proof.
- For PHEVs, `hp` and `torque_lbft` always describe the combustion engine. Combined system output appears only in caveats/comparison text.

# BMW drivetrain research

Public website: https://barsnbolts.github.io/bmw-solstice-buying-guide/

Publication and update details: `PUBLICATION.md`.

Open **BMW-Drivetrain-Report.html** in a web browser. It is one self-contained file: send that file to someone or copy it to your phone. No server, installation, account or external fonts/scripts are required. Source records remain readable without JavaScript; the full app navigation, search/filter and CSV-download controls require it. Original source links require internet access. Some phone file-preview apps may disable interactive HTML; use a browser or the accompanying CSV in that case.

- `BMW-Drivetrain-Report.html` — self-contained application: overview, market, donor guide, buying tools and research; saved candidates, shareable filters and comparisons.
- `BMW-Listings.csv` — deduplicated records, native prices, dated CAD conversions, contents, condition and source URLs.
- `REPORT.md` — concise written conclusions and benchmark purchase judgments.
- `research/` — detailed manufacturer-source notes, individual research datasets, explicit statistical memberships, exclusions and deduplication log.
- `synthesize.py` then `build_report.py` — rebuild the report from saved evidence. The synthesis uses the already-installed `marked` executable at its recorded local path; viewing the completed HTML has no dependencies.

Original market snapshot: 25 September 2026. Classified follow-up and interface revision: 26 September 2026. The register now contains 125 records: 113 original records plus 12 classified leads; these leads do not alter the 21 original statistical cohorts. This is a market study, not a stock guarantee. No sellers were contacted and no purchases, bids, shipping quotes or vehicle inspections were performed. Exact healthy dressed 2020 M2 Competition / 55,000-km statistics are unavailable; provisional buying judgments are labelled accordingly. Some annual donor-code and hybrid gearbox boundaries remain unresolved in the technical appendices.

Validation: `python3 synthesize.py` checks cohort references, current-ask classifications, deduplication and FX examples. `python3 build_report.py --check` verifies HTML safety, record identity and the JavaScript model checks. Final browser checks cover desktop and a 390-pixel phone-sized viewport, search/filter behavior and layout overflow; this is responsive browser testing, not a physical-phone test.

## Sharing and updates

The published site is served from the `public-site/` checkout. A stable hosted URL shows the latest published HTML after republishing and reloading. It is publicly readable and may be indexed; it is not an access-controlled sharing link. The evidence is a dated snapshot, not an automatically refreshed inventory feed.

Google Drive can store/share the HTML or ZIP and replace a file through Manage versions, but it no longer hosts interactive websites. For phone browsing use the hosted link; for offline transfer use the self-contained HTML.

Rebuild after accepted research changes with `python3 synthesize.py`, `python3 build_report.py --check`, then `python3 build_report.py`. Review the rendered page and keep classified/historical evidence out of active comparable cohorts. After acceptance, run `python3 prepare_release.py` to refresh the explicit research archive and copy the three public artifacts into `public-site/`, then commit and push that checkout. GitHub Pages republishes the same URL. Validate the public content after deployment. Publishing alone does not re-check listings.

Original artifacts and renderer are preserved in `history/2026-09-25/`. Design comparison and validation receipts are in `research/design-comparison/`. Skill review material stays local and is not part of the public research pack.

## Application revision 3

The interface uses native HTML, CSS and JavaScript in `ui/`, assembled by `build_report.py`. It loads no external fonts, scripts or UI libraries. All records remain searchable; the market renders 20 at a time. Currency, saved candidates and comparison are browser-side tools, not seller verification. Saved candidates persist on the same browser when storage is available; share a view to carry the chosen IDs to another device.

The previous published interface is preserved in `history/2026-09-26-report-v2/`. Design acceptance and screenshots are in `research/design-comparison/v3/`. To change only the interface, skip synthesis: run the renderer checks, build, inspect and package. Research changes still require synthesis and evidence review.

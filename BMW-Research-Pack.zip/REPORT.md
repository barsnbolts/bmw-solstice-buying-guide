# BMW power for the Solstice

North American used-drivetrain buying study • observed 25 September 2026 • prices are asking prices unless explicitly marked otherwise.

## The buying decision

**Start with a first-generation B58 from a 540i, 740i, X3 M40i or X4 M40i if value matters most.** The recycler evidence includes engines with turbos at US$4,700–5,660, before freight and taxes. These share the useful B58 architecture; that does not establish identical sumps, accessories or exact engine suffixes. A cheap luxury-car donor can be more compelling than an enthusiast-car engine with an identical family name.

**Keep the S55 benchmark, but do not pay for the M2 badge automatically.** An M3/M4 S55 is a genuine alternative; verify the particular output/hardware variant and dress. The intriguing Canadian lead is an unconfirmed S55/M4 engine lead advertised at C$10,000 and 60,000 km by St-Bruno Auto Parts. Its description conflicts with the S55 interchange by saying “3.9”; engine identity, dressing and condition evidence are incomplete, so this is a verification priority rather than a proven bargain. The US$6,500 M2 Competition engine is damaged, not a healthy-engine comparable.

**S58 is the expensive step up; B48/B46 is a real four-cylinder path.** S58 SUV donors deserve attention, with a US$11,000 X3 M lead against a US$12,622.50 low-mileage M3 assembly. The 2022 SUV crankshaft update matters. Longitudinal B48/B46 engines retain a four-cylinder architecture closer to the LNF; transverse or hybrid variants need distinct assembly comparisons. No defensible dressed-weight or external-size advantage has been quantified.

## Original benchmark: dressed 2020 M2 Competition, about 55,000 km

There is **no adequately documented healthy, fully dressed exact-year/55,000-km cohort** in the captured evidence. Its empirical mean and median are therefore unavailable. “55,000 km” is about 34,175 miles, not 55,000 miles. All listing mileages remain seller-stated unless an auction labels the odometer actual; none was independently verified against service records.

Two adjacent-mileage 2021 M2 Competition recycler assemblies, at 29,000 and 33,000 miles, ask US$12,495 and US$12,500. Their mean and median are US$12,497.50 (C$17,666); dress is unspecified, so this is an **assembly-price reference**, not a dressed benchmark. A 2020 M2 Competition at 50,285 miles asks US$10,500 with turbos, but is materially higher mileage. A fully described M4 assembly with turbos/accessories at 87,498 miles asks US$10,495; a single item cannot establish a robust market average.

For a healthy engine whose turbos, intake/fuel equipment and necessary engine accessories are actually included, my provisional purchase-screening judgments are (the captured asks do not establish a matched dressed-engine market band):

| Purchase judgment | USD engine-only | CAD equivalent | Interpretation |
|---|---:|---:|---|
| Great | Below $10,000 | Below $14,136 | Worth prioritizing if the 55,000-km claim, health and dress hold up. A damaged or incomplete engine does not qualify just because it is cheap. |
| Fair | $10,000–12,500 | $14,136–17,670 | Anchored by captured M2 assemblies and M3/M4 turbo-equipped substitutes; this is buyer judgment, not a mileage-regression result. |
| High | Above $12,500 | Above $17,670 | Needs unusually strong contents/test evidence or another tangible benefit to beat the alternatives. |

Confidence is **low-to-moderate**, because the nearest low-mileage observations have incomplete dressing information and the fully specified observation is much higher mileage. No arbitrary mileage discount is used. A matched DCT package should be compared with the separate engine and exact-transmission asks; no fixed package premium or discount is assumed. The advertised US$14,950 RacingJunk package is stale and inaccessible, and its transmission identity is unresolved; it does not establish a current package market price.

## What constitutes the same useful engine?

| Candidate | Cheaper donors to search | Important distinction |
|---|---|---|
| S55 | F80 M3; F82/F83 M4 including convertibles | Same family as M2 Competition, but Competition/CS bedplate, cooling/package and GTS water-injection variants prevent universal tune-only equivalence. GTS water injection is not port fuel injection. |
| S58 | F97 X3 M / F98 X4 M | Genuine S58, not B58. Early SUV versus MY2022-on crankshaft matters. BMW's no-hardware-difference statement covers contemporary regular/Competition G80/G82 engines, not every S58 ever built. |
| B58 original | 540i, 740i, 640i GT, X3/X4 M40i as well as 340i/440i/M240i | Strong value cohort. Distinguish drivetrain/sump/accessory configuration and exact suffix. |
| B58 technical updates | 840i, newer 540i/740i, X5/X6/X7 40i, M340i/M440i, Z4/Supra | Integrated versus separate exhaust-manifold heads, fuel-pressure/cooling revisions and later dual-injection/Miller-cycle hardware are material. “Gen 2” is not a sufficient parts identity. |
| B58 plug-in hybrid / mild hybrid | 745e/750e, Canadian 550e, X5 45e/50e and newer 48 V cars/SUVs | Real engine candidates, but electric-machine placement and hybrid-specific transmission/front-end arrangements mean the complete package is different. Power-system output is not combustion-engine output. |
| B48/B46 longitudinal | 230i/330i/430i/530i, X3/X4 30i, Z4 30i, Supra 2.0; 330e/530e/740e separately | Useful four-cylinder alternatives; emissions suffix, generation, head, turbo and hybrid configuration matter. Cheaper does not imply the same upper-output internals. |
| B48 transverse | X1/X2, 2-Series Gran Coupe, related MINI | Different layout and transmission family. Still interesting for a fabrication-intensive race car, but not a like-for-like longitudinal dropout. |
| N55 ordinary / special | 135i/335i/535i/640i/740i and 35i SUVs; original M2 and X4 M40i separately | Original M2 is N55, not S55; BMW specifies M-derived pistons/bearing shells and track-oriented oiling. Ordinary N55 prices cannot appraise an M2 N55. |

The detailed manufacturer-source appendices below carry application years, type codes and unresolved boundaries. Badge alone is never accepted as proof of a particular engine generation.

## Engines, gearboxes and packages are different markets

The original B58 turbo-equipped recycler cohort has **n=4**, US$4,700–5,660, mean **US$5,177.50** and median **US$5,175** (C$7,319 / C$7,315). These are higher-mileage engines with incomplete accessory inventories. The G8x S58 seller-described complete/dropout cohort has **n=3**, US$12,622.50–13,889.90, mean **US$13,337.47** and median **US$13,500** (C$18,854 / C$19,084); one has unknown mileage. The early X3 M S58 is a separate **n=1** observation at US$11,000. Fully dressed, known-mileage family-wide averages are not established for B48/B46 or N55.

| Market | Captured native asks | Interpretation |
|---|---:|---|
| Ordinary N55 engine assemblies | $2,999.94–3,248.95 USD, n=2 | Accessories not itemized; source-year/code ambiguity prevents an exact-version appraisal. Their median is $3,124.45 USD (C$4,417). |
| Original M2 N55 | $7,499.95 USD, n=1 damaged long block | Cracked/repaired oil pan; excluded from healthy dressed averages. No defensible healthy M2 N55 band established. |
| B46/B48 engines | B46 AWD assembly $3,386.63; B46 G20 $3,999; B46D X3 $4,289; seller-labelled B48 $3,500 USD | Separate code/donor observations, not one pooled four-cylinder average. B46 long block at $1,950 is a separate completeness class. |
| N55 RWD 8HP45 | $359.14–799.99 USD, n=3 | Mean $600.72; median $643.03. Converter/ancillaries unspecified. |
| B-engine 8HP50 / 8HP51 examples | 540i RWD 50Z $1,045; advertised AWD 50 $1,115.95; 330i RWD 51Z $930.23 USD | Different case, output and donor specifications; not pooled. |
| BMW V8-donor 8HP70X / 8HP75 | $1,089.89 / $1,250 USD, n=1 each | Transmission-only adaptation candidates. The 70X's earlier $708.43 search price could not be reproduced on the opened page; 75 listing says xDrive but uses Z suffix. Neither is a proven bolt-on to the target engines. |
| F8x-advertised DCT | $1,400–1,600 USD, n=2 | Mean/median $1,500. BMW training says GS7D36BG while a BMW parts-catalog mirror also uses GS7D36SG for F80. This nomenclature conflict does not prove sellers wrong; verify exact part/VIN/case. |
| Original M2 N55 DCT | $2,499.99 USD, n=1 | Separate 2017 M2 donor, 34k miles; stock unresolved. |
| S58 automatic | xDrive asks $3,500–3,995.95, n=2; G80 RWD $4,999.01, n=1 USD | One xDrive listing has a Z/X title conflict. Do not price the transfer case as included. |
| 330e 8P75H hybrid transmission | $900–1,559.99 USD, n=2 | Electric-machine/ancillary completeness unresolved. Not an ordinary converter-equipped 8HP. |
| M340i B58 + automatic package | $9,499 USD / C$13,428, n=1 | Seller-offered 2020 RWD package at 59k miles; contents/tag need confirmation. No returns. |
| M2 Competition S55 drivetrain package | $14,950 USD / C$21,133, n=1 stale lead | Blocked page, old surfaced update, automatic type unconfirmed. Excluded from current package statistics. |

There is no verified current S58 engine-plus-transmission package or B48/N55 package cohort in this sample. Adding separate component asks is useful for comparing alternatives, but is not evidence that a seller will offer that combination for the summed price. Factory S55 cars used DCT when automatic; an S55–8HP combination is an aftermarket pairing. Factory S58 automatics are M 8HP units, not DCT. The gearbox appendix distinguishes 45/50/51/76, transmission-only 70/75 candidates, newer 48 V 60MH-family evidence and PHEV 75/80 families. The newer X5 50e catalogue labels its unit GA8HP80XPH; that is materially different from treating every hybrid as a 330e 8P75H.

## Ontario cost boundary

All converted prices use **US$1 = C$1.4136**, the Bank of Canada daily observation for **24 September 2026**, the latest returned when checked on 25 September. Card/bank conversion spreads are not included. [Bank of Canada daily rates](https://www.bankofcanada.ca/rates/exchange/daily-exchange-rates/) · [Dated API observation](https://www.bankofcanada.ca/valet/observations/FXUSDCAD/json?start_date=2026-09-24&end_date=2026-09-25).

Ontario HST is 13%. The following is **purchase-price plus a 13% tax illustration, not an Ontario-delivered quote**. Seller tax treatment and import collection can differ; freight, broker/auction fees, exchange spreads, duties and any applicable surtaxes remain additional/unknown. A US seller does not establish US origin or duty-free treatment. No Ontario freight quote was obtained. [CRA rates](https://www.canada.ca/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-place-supply.html) · [CBSA importing guidance](https://www.cbsa-asfc.gc.ca/import/guide-3-eng.html).

| Example | Native ask | CAD before tax | CAD × 1.13 illustration |
|---|---:|---:|---:|
| St-Bruno possible S55, 60,000 km; identity/dress unresolved | C$10,000 | $10,000 | $11,300 |
| General Auto 740i B58 with turbo | US$5,000 | $7,068 | $7,987 |
| Parts Box X3 M S58, 51k miles | US$11,000 | $15,550 | $17,571 |
| Cyber Auto M3 S58, 8,102 miles | US$12,622.50 | $17,843 | $20,163 |

The S58 sellers show US$350 freight in their listings, but its destination/eligibility is not an Ontario quotation; it is excluded above. For a whole donor, acquisition cost is hammer/buy-now price plus the actual buyer, bidding, gate, transport, storage, tax and import charges. **Conservative part-out proceeds are set to zero for comparisons** because no supportable resale inventory, costs or completed sales were established. A hypothetical net-after-part-out value is not a buying budget.

## Search coverage and interpretation

The investigation searched US and Canadian listings across recycler inventory, independent dismantlers, eBay, Kijiji, OfferUp, Craigslist, enthusiast/specialist listings, Copart and auction archives. Live Car-Part searches used All Areas and price ordering, exposing repeated broker listings of the same stock. LKQ inventory appeared through the recycler network; direct LKQ access was limited. Marketplace access did not yield a retained verifiable item. IAA fee evidence was accessible, but no sufficiently documented IAA donor was retained. No adequately documented North American half-cut was found. These are coverage limits, not proof that no such opportunities exist.

Listings are deduplicated by exact item URL and identified stock/donor evidence; uncertain cross-list duplicates remain marked. Multiple parts from one donor are separate items, not duplicate engines. A selected, accessible sample is not a census of all North American inventory. A price visible on a listing page is not confirmation that a seller still possesses the item. No sellers were contacted, no inspections occurred, and no purchases or bids were placed.

Healthy/used asking statistics exclude disclosed damage, cores, rebuilt/core-exchange offerings, ended/archived asks, auction bids and search-only leads. Even retained used-condition listings are seller claims, not independently proven healthy engines. Each statistical cohort names completeness and mileage limitations. Unknown-mileage records stay visible and are never normalized to 55,000 km.

To continue efficiently, search both codes and ordinary terms: `S55 motor`, `M4 part out`, `740i engine`, `540i motor assembly`, `B58B30M1`, `B58B30M2`, `X5 45e engine`, `X3 M engine`, `530i B46`, `330e engine`, plus the exact gearbox tag. Search recyclers by donor/year and interchange, then compare origin-yard stock IDs. For each shortlisted item, the unanswered purchasing facts are the donor VIN/production date, documented mileage, damage/run-test evidence, exact attached hardware, transmission tag and an Ontario freight quote. These are evidence needed to evaluate the item, not mandatory ECU/TCU/harness purchases.
